// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Cole Fredericks
// 3/24/26
// SNHU CS 405
// 4-1 Exceptions
//

#include <iostream>
#include <stdexcept> // Had to add for runtime_error
#include <exception> // Had to add for std::exception

// Custom exception for the custom application logic
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Something went wrong in the custom application logic.";
    }

};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    // Lets the user know this part started before the exception gets thrown
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    
    // Throwing a standard exception here so it can be caught in the above function
    throw std::runtime_error("Something went wrong in the extra application logic.");

}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    // Tells the user this part has started
    std::cout << "Running Custom Application Logic." << std::endl;

    // Putting this in a try/catch block keeps the program going
    try
    {
        if (do_even_more_custom_application_logic())
        {

            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        std::cout << "Caught Exception In Custom Application Logic: " << e.what() << std::endl;

    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    // Tells the user they're leaving this paryt before the exception gets thrown
    std::cout << "Leaving Custom Application Logic." << std::endl;

    throw CustomException();// Throws a custom exception here so main catches it directly


}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    if (den == 0) // Checks for divide by zero here so it throws 
                  // an exception, instead of just giving inf
    {
        throw std::runtime_error("Cannot divide by zero.");

    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f; 
    float denominator = 0;

    try // Catches the divide exception here so the noexcept function doesn't terminate
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }

    catch (const std::runtime_error& e)
    {
        std::cout << "Caught Exception In do_division: " << e.what() << std::endl;
    }
}

int main()
{
    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    
    // By wrapping the main work in a try/catch block, any exceptions get handled here
    try
    {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();
        do_custom_application_logic();

    }
    catch (const CustomException& e)
    {
        std::cout << "Caught Custom Exception In Main: " << e.what() << std::endl;
    }

    catch (const std::exception& e)
    {
        std::cout << "Caught Standard Exception In Main: " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Caught An Unknown Exception In Main." << std::endl;
    }


}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu